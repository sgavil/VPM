var searchData=
[
  ['image_39',['Image',['../interfacecom_1_1gavilanvillar_1_1engine_1_1_image.html',1,'com::gavilanvillar::engine']]],
  ['init_40',['init',['../classcom_1_1gavilanvillar_1_1android__engine_1_1_a_game.html#a6cf053c8a24627d7915ee6cd85b5b359',1,'com.gavilanvillar.android_engine.AGame.init()'],['../classcom_1_1gavilanvillar_1_1desktop__engine_1_1_p_c_game.html#ae8cdf3ab8aef3e547b19380ca160ae51',1,'com.gavilanvillar.desktop_engine.PCGame.init()']]],
  ['input_41',['Input',['../interfacecom_1_1gavilanvillar_1_1engine_1_1_input.html',1,'com::gavilanvillar::engine']]],
  ['isclicked_42',['isClicked',['../classcom_1_1gavilanvillar_1_1engine_1_1_button.html#a605f884c6b3ff454ec2179f2532feba3',1,'com::gavilanvillar::engine::Button']]],
  ['issoundmuted_43',['isSoundMuted',['../classcom_1_1gavilanvillar_1_1android__engine_1_1_a_audio.html#af77b208b11219c1f5488cbaf5b4a9d1c',1,'com.gavilanvillar.android_engine.AAudio.isSoundMuted()'],['../interfacecom_1_1gavilanvillar_1_1engine_1_1_audio.html#a3d8afe8746559f679fa8b36fd21979a7',1,'com.gavilanvillar.engine.Audio.isSoundMuted()'],['../classcom_1_1gavilanvillar_1_1desktop__engine_1_1_p_c_audio.html#a0fdf61010119ffa3a615be3ea05a7d2f',1,'com.gavilanvillar.desktop_engine.PCAudio.isSoundMuted()']]]
];
